/* CSE564: Software Design
 * Group 6
 * Names: Albert Patron
 *        Vaishak Ramesh Vellore
 *        Siva Pranav Mandadi
 *        Koushik Kotamraju
 *        Ananya Dutta
 *
 * Final Submission 12/4/2017:
 *
 */

#include "project.h"

void startAllMotors() {
    Right_Eyebrow_Start();
    Left_Eyebrow_Start();
    Eye_Ball_Vertical_Start();
    Eye_Ball_Horizontal_Start();
    Eyelid_Group_Start();
    Neck_Start();
    Base_Jaw_Start();
    Lip_Start();
}

/* S1, PIN 0.0
 * This controls the movement for the inner Right Eyebrow motor.
 * @Parameters:
 *  int x which gives the angle the robot moves.
 * Each motor has it's own offset, and range of movement.
 */

void runRightEyebrowIn(int x) {
    int offset = 0;
    Right_Eyebrow_WriteCompare1(x);
}

// S3, PIN 0.1
void runRightEyebrowOut(int x) {
    int offset = 0;
    Right_Eyebrow_WriteCompare2(x);
}

// S2, PIN 0.2
void runLeftEyebrowIn(int x) {
    int offset = 0;
    Left_Eyebrow_WriteCompare1(x);
}

// S4, PIN 0.3
void runLeftEyebrowOut(int x) {
    Left_Eyebrow_WriteCompare2(x);
}

// S5, PIN 0.4
void runEyeBallVerticalRight(int x) {
    Eye_Ball_Horizontal_WriteCompare1(x);
}

// S6, PIN 0.5
void runEyeBallVerticalLeft(int x) {
    Eye_Ball_Horizontal_WriteCompare2(x);
}

// S7, PIN 0.6
void runEyeBallHorizontalRight(int x) {
    Eye_Ball_Vertical_WriteCompare1(x);
}

// S8, PIN 0.7
void runEyeBallHorizontalLeft(int x) {
    Eye_Ball_Vertical_WriteCompare2(x);
}

// S9, PIN 1.2
void runEyeLidGroupVertical(int x) {
    Eyelid_Group_WriteCompare2(x);
}

// S10, 1.4
void runEyeLidGroupHorizontal(int x) {
    Eyelid_Group_WriteCompare1(x);
}

// S14, 2.0
void runNeckRight(int x) {
    Neck_WriteCompare1(x);
}

// S15, 2.1
void runNeckLeft(int x) {
    Neck_WriteCompare2(x);
}

// S11, 1.5
void runJaw(x) {
    Base_Jaw_WriteCompare1(x);
}

// S16, 2.2
void runBase(int x) {
    Base_Jaw_WriteCompare2(x);
}

// S12, PIN 1.6
void runLipRight(int x) {
    Lip_WriteCompare1(x);
}

// S13, PIN 1.7
void runLipLeft(int x) {
    Lip_WriteCompare1(x);
}

/**
 * This code will test each of the Servos motors 180 degrees.
 * Motors will run indefinitely back and fourth full motion.
 */
void runAllMotors180() {
    int x = 1800;
    int loopVar = 1;
    while (loopVar==1) {
        if (x>=(7801)) {
            x=1800;
        }

        runRightEyebrowIn(x);
        runRightEyebrowOut(x);
        runLeftEyebrowIn(x);
        runLeftEyebrowOut(x);
        runEyeBallHorizontalRight(x);
        runEyeBallHorizontalLeft(x);
        runEyeBallVerticalRight(x);
        runEyeBallVerticalLeft(x);
        runEyeLidGroupVertical(x);
        runEyeLidGroupHorizontal(x);
        runNeckRight(x);
        runNeckLeft(x);
        runJaw(x);
        runBase(x);
        runLipRight(x);
        runLipLeft(x);
        
        x+=6000;
        CyDelay(500);
    }   
}

void runDebugAction1() {
    
    Right_Eyebrow_Start();
    Left_Eyebrow_Start();
    int x = 1800;
    int loopVar = 0;
    
    while (loopVar<6) {
        if (x>=(7801)) {
            x=1800;
            loopVar++;
        }
        
        if (loopVar<3) {
            runRightEyebrowIn(x);
            runLeftEyebrowIn(x);
            runRightEyebrowOut(x);
            runLeftEyebrowOut(x);
        } 
        
        else {
            runJaw(x);
        }
        x+=6000;
        CyDelay(500);
    }
}

void rollEyes() {
    Eye_Ball_Vertical_Start();
    Eye_Ball_Horizontal_Start();

    int x = 1800;
    int y = 3600;
    int loopVar = 0;
    while (loopVar<5) {
        if (x>=(7801)) {
            x=1800;
        }
        if (y>=(4801)) {
            y=1800;
            loopVar++;
        }
        
        runEyeBallVerticalRight(y);
        runEyeBallVerticalLeft(y);
        x+=5000;
        y+=2000;
        CyDelay(1000);
    } 
 }

void mouthOpening() {
Base_Jaw_Start();
        int x = 2400;
    int loopVar = 0;
    while (loopVar<6) {
        if (x>=(6401)) {
            x=2400;
        }
        runJaw(x);
        x+=4000;
        CyDelay(100);
    } 
}

void eyesAction() {

    Right_Eyebrow_Start();
    Left_Eyebrow_Start();
    int x = 1800;
    int loopVar = 0;
    
    while (loopVar<3) {
        if (x>=(5801)) {
            x=1800;
            loopVar++;
        }
        runRightEyebrowIn(x);
        runRightEyebrowOut(7801-x);
        
        runLeftEyebrowIn(10000-x);
        runLeftEyebrowOut(x);

        x+=4000;
        CyDelay(1500);
    }
    
    Eyelid_Group_Start();
    
    x = 1800;
    loopVar = 0;
    while (loopVar<5) {
        if (x>=(5801)) {
            x=1800;
            loopVar++;
        }
        runEyeLidGroupHorizontal(x);
        x+=4000;
        CyDelay(500);
    }
    
    x = 1800;
    loopVar = 0;
    while (loopVar<5) {
        if (x>=(5801)) {
            x=1800;
            loopVar++;
        }
        runEyeLidGroupVertical(x);
        x+=4000;
        CyDelay(500);
    }
    runEyeLidGroupVertical(5801);
    
    rollEyes();
    mouthOpening();
}

void blinkEyes() {
 
    Eyelid_Group_Start();   
    int x = 1800;
    int loopVar = 1;
    while (loopVar==1) {
        if (x>=(5801)) {
            x=1800;
        }
        runEyeLidGroupVertical(x);
        x+=4000;
        CyDelay(500);
    }
}

void moveGroupEyeLids(int amount) {
    int FINAL_EYE_LIDS_UP = 3200;
    int FINAL_EYE_LIDS_DOWN = 1800;
    Eyelid_Group_Start();
    // Down
    if (amount == 0) {
        runEyeLidGroupHorizontal(FINAL_EYE_LIDS_DOWN);
    }
    // Normal
    if (amount == 1) {
        runEyeLidGroupHorizontal((FINAL_EYE_LIDS_DOWN+FINAL_EYE_LIDS_UP)/2-500);
    }
    // Up
    if (amount == 2) {
        runEyeLidGroupHorizontal(FINAL_EYE_LIDS_UP);
    }
}

void moveEyeBalls(int amount) {
    Eye_Ball_Vertical_Start();
    Eye_Ball_Horizontal_Start();
    
    int FINAL_RIGHT_UP = 4200;
    int FINAL_LEFT_UP = 3700;
    int FINAL_RIGHT_MID = 3500;
    int FINAL_LEFT_MID = 2900;
    int FINAL_RIGHT_DOWN = 2100;
    int FINAL_LEFT_DOWN = 1800;
    
    // Closed
    if (amount == 0) {
        runEyeBallVerticalRight(FINAL_RIGHT_DOWN);
        runEyeBallVerticalLeft(FINAL_LEFT_DOWN);
    }
    // Normal
    else if (amount == 1) {
        runEyeBallVerticalRight(FINAL_RIGHT_MID);
        runEyeBallVerticalLeft(FINAL_LEFT_MID);   
    }
    // Up
    else if (amount == 2) {
        runEyeBallVerticalRight(FINAL_RIGHT_UP);
        runEyeBallVerticalLeft(FINAL_LEFT_UP);   
    }    
}

void openJaw(int amount) {
Base_Jaw_Start();
    int FINAL_JAW_CLOSED = 6400;
    int FINAL_JAW_OPEN = 4300;
    int x = FINAL_JAW_OPEN;
    
    // closed
    if (amount == 0) {
        runJaw(FINAL_JAW_CLOSED);
    } 
    // halfway open
    else if (amount == 1) {
        runJaw((FINAL_JAW_CLOSED+FINAL_JAW_OPEN)/2);
    }
    // All the way open
    else if (amount == 2) {
        runJaw(FINAL_JAW_OPEN);   
    }
    else {
        int loopVar = 0;
        
        while (loopVar<6) {
            if (x>=(FINAL_JAW_CLOSED+1)) {
                x=FINAL_JAW_OPEN;
            }
            runJaw(x);
            x+=2100;
            CyDelay(1000);
        }
    }
}

// This will shift the eyebrows into different positions
void eyeBrows(int amount) {
    
    if (amount == 3) {
        int x = 5800;
        Right_Eyebrow_Start();
        Left_Eyebrow_Start();
        runRightEyebrowIn(x);
        runRightEyebrowOut(7801-x);
        runLeftEyebrowIn(10000-x);
        runLeftEyebrowOut(x);   
    }
    else if (amount == 2 ) {
        int x = 5000;
        Right_Eyebrow_Start();
        Left_Eyebrow_Start();
        runRightEyebrowIn(x);
        runRightEyebrowOut(7801-x);
        runLeftEyebrowIn(10000-x);
        runLeftEyebrowOut(x);   
    } else if (amount == 0) {
        int x = 2000;
        Right_Eyebrow_Start();
        Left_Eyebrow_Start();
        runRightEyebrowIn(x);
        runRightEyebrowOut(7801-x);
        runLeftEyebrowIn(10000-x);
        runLeftEyebrowOut(x);   
    }
    else {
        int FINAL_SAD = 7800;
        int x = 1800;
        while (x<FINAL_SAD+1) {
            Right_Eyebrow_Start();
            Left_Eyebrow_Start();
            runRightEyebrowIn(x);
            runRightEyebrowOut(7801-x);
            runLeftEyebrowIn(10000-x);
            runLeftEyebrowOut(x);
            x+=500;
            CyDelay(1000);
        }
    }
}

// This will slowly close the eyebrows in a sad position.
void eyeBrowsSlowSad() {
        int FINAL_SAD = 5800;
        int x = 1800;
        while (x<FINAL_SAD+1) {
            Right_Eyebrow_Start();
            Left_Eyebrow_Start();
            runRightEyebrowIn(x);
            runRightEyebrowOut(7801-x);
            runLeftEyebrowIn(10000-x);
            runLeftEyebrowOut(x);
            x+=500;
            CyDelay(100);
        }
}

void slowEyesClose() {
    Eyelid_Group_Start();
    int x = 6800;
    
    while (x>3599) {
        runEyeLidGroupVertical(x);
        x-=500;
        CyDelay(300);
    }
}

// This will open his eyes from 0 (closed) to 5 all the way open.
void openEyes(int amount) {
    Eyelid_Group_Start();
    
    int x = 7200;
    int counter = 0;
    /*
    while (x>3699) {
        runEyeLidGroupVertical(x);
        x-=1000;
        CyDelay(1000);
    }*/
    
    //Closed
    if (amount == 0) {
        runEyeLidGroupVertical(3500);
    }
    
    // Kind of closed
    if (amount == 1) {
        runEyeLidGroupVertical(5100);
    }
    
    //  Normal
    if (amount == 2) {
        runEyeLidGroupVertical(6000);
    }
    
    // all the way opened, shocked
    if (amount == 3) {
        runEyeLidGroupVertical(7200);
    }
    
}
void sleepingInClass() {
    
    Neck_Start();
    int x = 7500;
    int y = 1400;
    int counter = 0;
    
        runNeckRight(x);
        runNeckLeft(y);
        
    eyeBrows(0);
    CyDelay(1500);
    
    slowEyesClose();
    
    while (x>4099) {
        runNeckRight(x);
        runNeckLeft(y);
        x-=100;
        y+=100;
        CyDelay(80);
    }
    
    while (counter < 10) {
        if (counter%2==0) {
            y-=600;
        } else {
            y+=600;
        }
        runNeckLeft(y);
        CyDelay(500);
        counter++;
    }
    
}


void wakeUpExpression() {
    openEyes(0);
    CyDelay(1000);
    Neck_Start();
    CyDelay(1000);
    
    runNeckRight(4100);
    runNeckLeft(4800);
    
    openEyes(2);
    int x = 4099;
    int y = 4800;
    
    while (x<6601) {
        runNeckRight(x);
        runNeckLeft(y);
        x+=1250;
        y-=1250;
        CyDelay(100);
    }
    
    
    Base_Jaw_Start();
    
    // Look left and right
    int z = 2000;
    int LRCount = 0;
    while (LRCount<2) {
        if (z>5001) {
            z = 2000;
            LRCount++;
        }
        runBase(z);
        z+=3000;
        CyDelay(1000);
    }
    
    runBase(4000);
    
    
    openEyes(3);
    eyeBrows(2);
    openJaw(2);
        
    
}

void equalibriumAction() {
    openJaw(0);
    eyeBrows(0);
    openEyes(3);
    moveEyeBalls(1);
    moveGroupEyeLids(1);
    
    Neck_Start();
    Base_Jaw_Start();
    runNeckRight(6400);
    runNeckLeft(2100);
    runBase(4000);    
    
}
void Greet() {
    Neck_Start();
    CyDelay(1000);
    
    int x = 7500;
    int y = 1400;
    
    while (x>4099) {
        runNeckRight(x);
        runNeckLeft(y);
        x-=300;
        y+=300;
        CyDelay(80);
    }
    
    equalibriumAction();
    
    CyDelay(2000);

}


void laugh() {
    eyeBrows(3);
    Base_Jaw_Start();
    int FINAL_JAW_CLOSED = 6400;
    int FINAL_JAW_OPEN = 4300;
    int midPoint = 6000;
    
    int x = FINAL_JAW_OPEN;
    int loopVar = 0;
    int y = 2300;
    int counter = 0;
    while (loopVar<20) {
        if (x>=(midPoint+1)) {
            x=FINAL_JAW_OPEN;
            loopVar++;
        }
        runJaw(x);
        
        if (counter%2==0) {
            y-=1000;
        } else {
            y+=1000;
        }
        runNeckLeft(y);
        counter++;
        
        x+=1700;
        CyDelay(100);
    }
}
int main() 
{
    // Start all motors.
    // Run this before any action items.
    // This will lock all motors in correct/natural place.
    //startAllMotors();
    // Send signal to run all motors simultaneously.
    //runAllMotors180();

    equalibriumAction();
    CyDelay(1000);
    
    Greet();
    sleepingInClass();
    wakeUpExpression();
    CyDelay(1000);
    equalibriumAction();
    laugh();
    equalibriumAction();
    
    return 0;
}