/*******************************************************************************
* File Name: Eyelid_Group_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Eyelid_Group.h"

static Eyelid_Group_backupStruct Eyelid_Group_backup;


/*******************************************************************************
* Function Name: Eyelid_Group_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eyelid_Group_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Eyelid_Group_SaveConfig(void) 
{

    #if(!Eyelid_Group_UsingFixedFunction)
        #if(!Eyelid_Group_PWMModeIsCenterAligned)
            Eyelid_Group_backup.PWMPeriod = Eyelid_Group_ReadPeriod();
        #endif /* (!Eyelid_Group_PWMModeIsCenterAligned) */
        Eyelid_Group_backup.PWMUdb = Eyelid_Group_ReadCounter();
        #if (Eyelid_Group_UseStatus)
            Eyelid_Group_backup.InterruptMaskValue = Eyelid_Group_STATUS_MASK;
        #endif /* (Eyelid_Group_UseStatus) */

        #if(Eyelid_Group_DeadBandMode == Eyelid_Group__B_PWM__DBM_256_CLOCKS || \
            Eyelid_Group_DeadBandMode == Eyelid_Group__B_PWM__DBM_2_4_CLOCKS)
            Eyelid_Group_backup.PWMdeadBandValue = Eyelid_Group_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(Eyelid_Group_KillModeMinTime)
             Eyelid_Group_backup.PWMKillCounterPeriod = Eyelid_Group_ReadKillTime();
        #endif /* (Eyelid_Group_KillModeMinTime) */

        #if(Eyelid_Group_UseControl)
            Eyelid_Group_backup.PWMControlRegister = Eyelid_Group_ReadControlRegister();
        #endif /* (Eyelid_Group_UseControl) */
    #endif  /* (!Eyelid_Group_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Eyelid_Group_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eyelid_Group_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Eyelid_Group_RestoreConfig(void) 
{
        #if(!Eyelid_Group_UsingFixedFunction)
            #if(!Eyelid_Group_PWMModeIsCenterAligned)
                Eyelid_Group_WritePeriod(Eyelid_Group_backup.PWMPeriod);
            #endif /* (!Eyelid_Group_PWMModeIsCenterAligned) */

            Eyelid_Group_WriteCounter(Eyelid_Group_backup.PWMUdb);

            #if (Eyelid_Group_UseStatus)
                Eyelid_Group_STATUS_MASK = Eyelid_Group_backup.InterruptMaskValue;
            #endif /* (Eyelid_Group_UseStatus) */

            #if(Eyelid_Group_DeadBandMode == Eyelid_Group__B_PWM__DBM_256_CLOCKS || \
                Eyelid_Group_DeadBandMode == Eyelid_Group__B_PWM__DBM_2_4_CLOCKS)
                Eyelid_Group_WriteDeadTime(Eyelid_Group_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(Eyelid_Group_KillModeMinTime)
                Eyelid_Group_WriteKillTime(Eyelid_Group_backup.PWMKillCounterPeriod);
            #endif /* (Eyelid_Group_KillModeMinTime) */

            #if(Eyelid_Group_UseControl)
                Eyelid_Group_WriteControlRegister(Eyelid_Group_backup.PWMControlRegister);
            #endif /* (Eyelid_Group_UseControl) */
        #endif  /* (!Eyelid_Group_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: Eyelid_Group_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eyelid_Group_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Eyelid_Group_Sleep(void) 
{
    #if(Eyelid_Group_UseControl)
        if(Eyelid_Group_CTRL_ENABLE == (Eyelid_Group_CONTROL & Eyelid_Group_CTRL_ENABLE))
        {
            /*Component is enabled */
            Eyelid_Group_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            Eyelid_Group_backup.PWMEnableState = 0u;
        }
    #endif /* (Eyelid_Group_UseControl) */

    /* Stop component */
    Eyelid_Group_Stop();

    /* Save registers configuration */
    Eyelid_Group_SaveConfig();
}


/*******************************************************************************
* Function Name: Eyelid_Group_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eyelid_Group_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Eyelid_Group_Wakeup(void) 
{
     /* Restore registers values */
    Eyelid_Group_RestoreConfig();

    if(Eyelid_Group_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        Eyelid_Group_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
