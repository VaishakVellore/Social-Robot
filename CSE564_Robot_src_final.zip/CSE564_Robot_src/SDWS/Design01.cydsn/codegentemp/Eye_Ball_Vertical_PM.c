/*******************************************************************************
* File Name: Eye_Ball_Vertical_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Eye_Ball_Vertical.h"

static Eye_Ball_Vertical_backupStruct Eye_Ball_Vertical_backup;


/*******************************************************************************
* Function Name: Eye_Ball_Vertical_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eye_Ball_Vertical_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Eye_Ball_Vertical_SaveConfig(void) 
{

    #if(!Eye_Ball_Vertical_UsingFixedFunction)
        #if(!Eye_Ball_Vertical_PWMModeIsCenterAligned)
            Eye_Ball_Vertical_backup.PWMPeriod = Eye_Ball_Vertical_ReadPeriod();
        #endif /* (!Eye_Ball_Vertical_PWMModeIsCenterAligned) */
        Eye_Ball_Vertical_backup.PWMUdb = Eye_Ball_Vertical_ReadCounter();
        #if (Eye_Ball_Vertical_UseStatus)
            Eye_Ball_Vertical_backup.InterruptMaskValue = Eye_Ball_Vertical_STATUS_MASK;
        #endif /* (Eye_Ball_Vertical_UseStatus) */

        #if(Eye_Ball_Vertical_DeadBandMode == Eye_Ball_Vertical__B_PWM__DBM_256_CLOCKS || \
            Eye_Ball_Vertical_DeadBandMode == Eye_Ball_Vertical__B_PWM__DBM_2_4_CLOCKS)
            Eye_Ball_Vertical_backup.PWMdeadBandValue = Eye_Ball_Vertical_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(Eye_Ball_Vertical_KillModeMinTime)
             Eye_Ball_Vertical_backup.PWMKillCounterPeriod = Eye_Ball_Vertical_ReadKillTime();
        #endif /* (Eye_Ball_Vertical_KillModeMinTime) */

        #if(Eye_Ball_Vertical_UseControl)
            Eye_Ball_Vertical_backup.PWMControlRegister = Eye_Ball_Vertical_ReadControlRegister();
        #endif /* (Eye_Ball_Vertical_UseControl) */
    #endif  /* (!Eye_Ball_Vertical_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Eye_Ball_Vertical_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eye_Ball_Vertical_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Eye_Ball_Vertical_RestoreConfig(void) 
{
        #if(!Eye_Ball_Vertical_UsingFixedFunction)
            #if(!Eye_Ball_Vertical_PWMModeIsCenterAligned)
                Eye_Ball_Vertical_WritePeriod(Eye_Ball_Vertical_backup.PWMPeriod);
            #endif /* (!Eye_Ball_Vertical_PWMModeIsCenterAligned) */

            Eye_Ball_Vertical_WriteCounter(Eye_Ball_Vertical_backup.PWMUdb);

            #if (Eye_Ball_Vertical_UseStatus)
                Eye_Ball_Vertical_STATUS_MASK = Eye_Ball_Vertical_backup.InterruptMaskValue;
            #endif /* (Eye_Ball_Vertical_UseStatus) */

            #if(Eye_Ball_Vertical_DeadBandMode == Eye_Ball_Vertical__B_PWM__DBM_256_CLOCKS || \
                Eye_Ball_Vertical_DeadBandMode == Eye_Ball_Vertical__B_PWM__DBM_2_4_CLOCKS)
                Eye_Ball_Vertical_WriteDeadTime(Eye_Ball_Vertical_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(Eye_Ball_Vertical_KillModeMinTime)
                Eye_Ball_Vertical_WriteKillTime(Eye_Ball_Vertical_backup.PWMKillCounterPeriod);
            #endif /* (Eye_Ball_Vertical_KillModeMinTime) */

            #if(Eye_Ball_Vertical_UseControl)
                Eye_Ball_Vertical_WriteControlRegister(Eye_Ball_Vertical_backup.PWMControlRegister);
            #endif /* (Eye_Ball_Vertical_UseControl) */
        #endif  /* (!Eye_Ball_Vertical_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: Eye_Ball_Vertical_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eye_Ball_Vertical_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Eye_Ball_Vertical_Sleep(void) 
{
    #if(Eye_Ball_Vertical_UseControl)
        if(Eye_Ball_Vertical_CTRL_ENABLE == (Eye_Ball_Vertical_CONTROL & Eye_Ball_Vertical_CTRL_ENABLE))
        {
            /*Component is enabled */
            Eye_Ball_Vertical_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            Eye_Ball_Vertical_backup.PWMEnableState = 0u;
        }
    #endif /* (Eye_Ball_Vertical_UseControl) */

    /* Stop component */
    Eye_Ball_Vertical_Stop();

    /* Save registers configuration */
    Eye_Ball_Vertical_SaveConfig();
}


/*******************************************************************************
* Function Name: Eye_Ball_Vertical_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  Eye_Ball_Vertical_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Eye_Ball_Vertical_Wakeup(void) 
{
     /* Restore registers values */
    Eye_Ball_Vertical_RestoreConfig();

    if(Eye_Ball_Vertical_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        Eye_Ball_Vertical_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
