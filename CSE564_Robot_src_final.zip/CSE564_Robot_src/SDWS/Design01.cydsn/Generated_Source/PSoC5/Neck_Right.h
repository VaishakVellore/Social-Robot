/*******************************************************************************
* File Name: Neck_Right.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Neck_Right_H) /* Pins Neck_Right_H */
#define CY_PINS_Neck_Right_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Neck_Right_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Neck_Right__PORT == 15 && ((Neck_Right__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Neck_Right_Write(uint8 value);
void    Neck_Right_SetDriveMode(uint8 mode);
uint8   Neck_Right_ReadDataReg(void);
uint8   Neck_Right_Read(void);
void    Neck_Right_SetInterruptMode(uint16 position, uint16 mode);
uint8   Neck_Right_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Neck_Right_SetDriveMode() function.
     *  @{
     */
        #define Neck_Right_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Neck_Right_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Neck_Right_DM_RES_UP          PIN_DM_RES_UP
        #define Neck_Right_DM_RES_DWN         PIN_DM_RES_DWN
        #define Neck_Right_DM_OD_LO           PIN_DM_OD_LO
        #define Neck_Right_DM_OD_HI           PIN_DM_OD_HI
        #define Neck_Right_DM_STRONG          PIN_DM_STRONG
        #define Neck_Right_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Neck_Right_MASK               Neck_Right__MASK
#define Neck_Right_SHIFT              Neck_Right__SHIFT
#define Neck_Right_WIDTH              1u

/* Interrupt constants */
#if defined(Neck_Right__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Neck_Right_SetInterruptMode() function.
     *  @{
     */
        #define Neck_Right_INTR_NONE      (uint16)(0x0000u)
        #define Neck_Right_INTR_RISING    (uint16)(0x0001u)
        #define Neck_Right_INTR_FALLING   (uint16)(0x0002u)
        #define Neck_Right_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Neck_Right_INTR_MASK      (0x01u) 
#endif /* (Neck_Right__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Neck_Right_PS                     (* (reg8 *) Neck_Right__PS)
/* Data Register */
#define Neck_Right_DR                     (* (reg8 *) Neck_Right__DR)
/* Port Number */
#define Neck_Right_PRT_NUM                (* (reg8 *) Neck_Right__PRT) 
/* Connect to Analog Globals */                                                  
#define Neck_Right_AG                     (* (reg8 *) Neck_Right__AG)                       
/* Analog MUX bux enable */
#define Neck_Right_AMUX                   (* (reg8 *) Neck_Right__AMUX) 
/* Bidirectional Enable */                                                        
#define Neck_Right_BIE                    (* (reg8 *) Neck_Right__BIE)
/* Bit-mask for Aliased Register Access */
#define Neck_Right_BIT_MASK               (* (reg8 *) Neck_Right__BIT_MASK)
/* Bypass Enable */
#define Neck_Right_BYP                    (* (reg8 *) Neck_Right__BYP)
/* Port wide control signals */                                                   
#define Neck_Right_CTL                    (* (reg8 *) Neck_Right__CTL)
/* Drive Modes */
#define Neck_Right_DM0                    (* (reg8 *) Neck_Right__DM0) 
#define Neck_Right_DM1                    (* (reg8 *) Neck_Right__DM1)
#define Neck_Right_DM2                    (* (reg8 *) Neck_Right__DM2) 
/* Input Buffer Disable Override */
#define Neck_Right_INP_DIS                (* (reg8 *) Neck_Right__INP_DIS)
/* LCD Common or Segment Drive */
#define Neck_Right_LCD_COM_SEG            (* (reg8 *) Neck_Right__LCD_COM_SEG)
/* Enable Segment LCD */
#define Neck_Right_LCD_EN                 (* (reg8 *) Neck_Right__LCD_EN)
/* Slew Rate Control */
#define Neck_Right_SLW                    (* (reg8 *) Neck_Right__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Neck_Right_PRTDSI__CAPS_SEL       (* (reg8 *) Neck_Right__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Neck_Right_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Neck_Right__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Neck_Right_PRTDSI__OE_SEL0        (* (reg8 *) Neck_Right__PRTDSI__OE_SEL0) 
#define Neck_Right_PRTDSI__OE_SEL1        (* (reg8 *) Neck_Right__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Neck_Right_PRTDSI__OUT_SEL0       (* (reg8 *) Neck_Right__PRTDSI__OUT_SEL0) 
#define Neck_Right_PRTDSI__OUT_SEL1       (* (reg8 *) Neck_Right__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Neck_Right_PRTDSI__SYNC_OUT       (* (reg8 *) Neck_Right__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Neck_Right__SIO_CFG)
    #define Neck_Right_SIO_HYST_EN        (* (reg8 *) Neck_Right__SIO_HYST_EN)
    #define Neck_Right_SIO_REG_HIFREQ     (* (reg8 *) Neck_Right__SIO_REG_HIFREQ)
    #define Neck_Right_SIO_CFG            (* (reg8 *) Neck_Right__SIO_CFG)
    #define Neck_Right_SIO_DIFF           (* (reg8 *) Neck_Right__SIO_DIFF)
#endif /* (Neck_Right__SIO_CFG) */

/* Interrupt Registers */
#if defined(Neck_Right__INTSTAT)
    #define Neck_Right_INTSTAT            (* (reg8 *) Neck_Right__INTSTAT)
    #define Neck_Right_SNAP               (* (reg8 *) Neck_Right__SNAP)
    
	#define Neck_Right_0_INTTYPE_REG 		(* (reg8 *) Neck_Right__0__INTTYPE)
#endif /* (Neck_Right__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Neck_Right_H */


/* [] END OF FILE */
